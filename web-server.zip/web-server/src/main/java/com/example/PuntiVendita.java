package com.example;

import java.util.ArrayList;

public class PuntiVendita {
    private int size;
    private ArrayList<PuntoVendita> listaRisultati;

    public PuntiVendita(){
        
    }

    public int getSize() {
        return size;
    }
    public ArrayList<PuntoVendita> getListaRisultati() {
        return listaRisultati;
    }
    public void setListaRisultati(ArrayList<PuntoVendita> listaRisultati) {
        this.listaRisultati = listaRisultati;
    }
    public void setSize(int size) {
        this.size = size;
    }
}