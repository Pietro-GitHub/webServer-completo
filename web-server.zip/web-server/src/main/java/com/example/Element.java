package com.example;

public class Element {
    private int annoDiNascita;
    private String cognome;
    private String nome;

    //costruttore di default
    public Element(){

    }

    public int getAnnoDiNascita() {
        return annoDiNascita;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getCognome() {
        return cognome;
    }
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }
    public void setAnnoDiNascita(int annoDiNascita) {
        this.annoDiNascita = annoDiNascita;
    }
}
